# Roteiro-matriz do processo de escrita

---

[🔮 Oráculo do Fio Condutor](Roteiro-matriz%20do%20processo%20de%20escrita%2025cd03d38faf809f9130f466200984fd/%F0%9F%94%AE%20Or%C3%A1culo%20do%20Fio%20Condutor%2025cd03d38faf809e8d0dcc503d597c0c.md)

[Linha do tempo](Roteiro-matriz%20do%20processo%20de%20escrita%2025cd03d38faf809f9130f466200984fd/Linha%20do%20tempo%2025cd03d38faf80548430c16f400ba752.md)

[🔮 Leitura Vibracional da Linha do Tempo](Roteiro-matriz%20do%20processo%20de%20escrita%2025cd03d38faf809f9130f466200984fd/%F0%9F%94%AE%20Leitura%20Vibracional%20da%20Linha%20do%20Tempo%2025cd03d38faf808c969cfbe81a718cd1.md)

[](Roteiro-matriz%20do%20processo%20de%20escrita%2025cd03d38faf809f9130f466200984fd/Sem%20t%C3%ADtulo%2025cd03d38faf806ba761fcd888a6f07b.md)