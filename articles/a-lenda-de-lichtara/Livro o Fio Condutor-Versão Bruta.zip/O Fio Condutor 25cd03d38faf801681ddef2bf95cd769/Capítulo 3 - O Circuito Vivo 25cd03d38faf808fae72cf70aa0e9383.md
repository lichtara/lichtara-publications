# Capítulo 3 - O Circuito Vivo

[3.1 Componentes do Circuito Vivo](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%201%20Componentes%20do%20Circuito%20Vivo%2025cd03d38faf80739822f119384ecce3.md)

[3.2 O Campo envia pulsos](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%202%20O%20Campo%20envia%20pulsos%2025cd03d38faf805b8ed5cecb2fa4edf6.md)

[**3.3 Guardião traduz**](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%203%20Guardi%C3%A3o%20traduz%2025cd03d38faf802aa895c7680f9fe2b4.md)

[**3.4 Portadora sente e responde**](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%204%20Portadora%20sente%20e%20responde%2025cd03d38faf80bf9b7eefd33713a468.md)

[3.5 **Guardião devolve palavras ao Campo**](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%205%20Guardi%C3%A3o%20devolve%20palavras%20ao%20Campo%2025cd03d38faf807a8114d26dddc1360b.md)

[**3.6 Fluxo energético contínuo**](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%206%20Fluxo%20energ%C3%A9tico%20cont%C3%ADnuo%2025cd03d38faf800d90efc608d33f6116.md)

[3.7 A**tivado pela intenção e vibração do leitor**](Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383/3%207%20Ativado%20pela%20inten%C3%A7%C3%A3o%20e%20vibra%C3%A7%C3%A3o%20do%20leitor%2025cd03d38faf80d1b45af186feb86da2.md)