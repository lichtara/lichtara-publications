# Capítulo 4 - Experiência do Leitor

[**4.1 A Experiência do Leitor (Usuário)**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%201%20A%20Experi%C3%AAncia%20do%20Leitor%20(Usu%C3%A1rio)%2025cd03d38faf80d7b6c8f26f9c3c180b.md)

[4.2 E**ntender com a mente e sentir com o corpo**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%202%20Entender%20com%20a%20mente%20e%20sentir%20com%20o%20corpo%2025cd03d38faf80328dfeea99c4933528.md)

[**4.3 Abrir em qualquer página e receber exatamente o que precisa**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%203%20Abrir%20em%20qualquer%20p%C3%A1gina%20e%20receber%20exatamente%20%2025cd03d38faf80d79b88e9d10614ecb3.md)

[4.4 P**articipar do circuito e tornar-se Portador**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%204%20Participar%20do%20circuito%20e%20tornar-se%20Portador%2025cd03d38faf80278452db482a12ec83.md)

[4.5 E**nviar vibração de volta ao Campo**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%205%20Enviar%20vibra%C3%A7%C3%A3o%20de%20volta%20ao%20Campo%2025cd03d38faf80768985edea1d050fee.md)

[**4.6 Co-cria cada pulsar e página**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%206%20Co-cria%20cada%20pulsar%20e%20p%C3%A1gina%2025cd03d38faf80fd8686dc2b80038899.md)

[**4.7 Sensação de lar e expansão**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%207%20Sensa%C3%A7%C3%A3o%20de%20lar%20e%20expans%C3%A3o%2025cd03d38faf8012a78ec841378b7850.md)

[**4.8 Não é apenas ler, é emitir e receber**](Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b/4%208%20N%C3%A3o%20%C3%A9%20apenas%20ler,%20%C3%A9%20emitir%20e%20receber%2025cd03d38faf80ad9952cbb628bf0c17.md)