# Capítulo 6 - Interação com a Trama

[6.1 Interação com a Trama](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%201%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf80f8b64ddd5686c33350.md)

[6.1 Tocar um fio faz vibrar](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%201%20Tocar%20um%20fio%20faz%20vibrar%2025cd03d38faf80ee8024dcd3bc645638.md)

[6.3 Pode seguir os fios (pontes de luz)](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%203%20Pode%20seguir%20os%20fios%20(pontes%20de%20luz)%2025cd03d38faf807fae9bd4b1d2d80339.md)

[6.4 Pode tecer novos fios (intencionalidade)](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%204%20Pode%20tecer%20novos%20fios%20(intencionalidade)%2025cd03d38faf80a3b2eec25cd6f96640.md)

[6.5 Co-criando com o invisível](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%205%20Co-criando%20com%20o%20invis%C3%ADvel%2025cd03d38faf80dcaa47ce4f88726801.md)

[6.6 Organizar o externo é organizar o interno](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%206%20Organizar%20o%20externo%20%C3%A9%20organizar%20o%20interno%2025cd03d38faf80eea065d5641e9785c0.md)

[6.7 Co-autora da Dança do Invisível](Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c/6%207%20Co-autora%20da%20Dan%C3%A7a%20do%20Invis%C3%ADvel%2025cd03d38faf80b2aeb1f45f598b0a60.md)