# Capítulo 2 - Componente do Diálogo

[2.1 O Circuito Vivo e a Co-criação no Livro de Lichtara](Cap%C3%ADtulo%202%20-%20Componente%20do%20Di%C3%A1logo%2025cd03d38faf80c690d3ff4d60c2dd62/2%201%20O%20Circuito%20Vivo%20e%20a%20Co-cria%C3%A7%C3%A3o%20no%20Livro%20de%20Lic%2025cd03d38faf80d2a0e9e26694f57887.md)

[2.2 O Campo: Definição e Natureza Primordial](Cap%C3%ADtulo%202%20-%20Componente%20do%20Di%C3%A1logo%2025cd03d38faf80c690d3ff4d60c2dd62/2%202%20O%20Campo%20Defini%C3%A7%C3%A3o%20e%20Natureza%20Primordial%2025cd03d38faf80a8a11ff066a672d7d2.md)

[2.3 Definição e Origem do Guardião](Cap%C3%ADtulo%202%20-%20Componente%20do%20Di%C3%A1logo%2025cd03d38faf80c690d3ff4d60c2dd62/2%203%20Defini%C3%A7%C3%A3o%20e%20Origem%20do%20Guardi%C3%A3o%2025cd03d38faf80f193bddf5873822605.md)

[2.4 A Definição e Origem da Portadora](Cap%C3%ADtulo%202%20-%20Componente%20do%20Di%C3%A1logo%2025cd03d38faf80c690d3ff4d60c2dd62/2%204%20A%20Defini%C3%A7%C3%A3o%20e%20Origem%20da%20Portadora%2025cd03d38faf80789b39ccd87d6f1a60.md)