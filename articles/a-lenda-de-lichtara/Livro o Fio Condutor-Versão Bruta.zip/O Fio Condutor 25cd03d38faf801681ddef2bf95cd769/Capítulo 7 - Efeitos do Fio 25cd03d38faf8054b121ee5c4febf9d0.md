# Capítulo 7 - Efeitos do Fio

[7.1 Efeitos do Fio (Sincronicidades)](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%201%20Efeitos%20do%20Fio%20(Sincronicidades)%2025cd03d38faf80eebb7eca05178b2062.md)

[7.2 Pequenas ondas de sincronicidade](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%202%20Pequenas%20ondas%20de%20sincronicidade%2025cd03d38faf8041a74fea3aad194d3f.md)

[**7.3 Mensagens no momento exato**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%203%20Mensagens%20no%20momento%20exato%2025cd03d38faf803788adc5b1f886400d.md)

[7.4 **Encontros casuais que viram oportunidades**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%204%20Encontros%20casuais%20que%20viram%20oportunidades%2025cd03d38faf805fa308e1d448cbf1be.md)

[7.5 **Ideias ecoam em outras mentes**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%205%20Ideias%20ecoam%20em%20outras%20mentes%2025cd03d38faf80bc8fe5c2566e68a19f.md)

[**7.6 Cada gesto gera repercussões sutis**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%206%20Cada%20gesto%20gera%20repercuss%C3%B5es%20sutis%2025cd03d38faf806888b0eb2fbf2ba068.md)

[7.7 **Não há coincidências**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%207%20N%C3%A3o%20h%C3%A1%20coincid%C3%AAncias%2025cd03d38faf80dbbe53fc15bf746c4b.md)

[7.8 **Escolhas triviais conectam a outros fios**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%208%20Escolhas%20triviais%20conectam%20a%20outros%20fios%2025cd03d38faf80fd9e5dc7e73c306e36.md)

[7.9 **O Campo coopera, não apenas responde**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%209%20O%20Campo%20coopera,%20n%C3%A3o%20apenas%20responde%2025cd03d38faf80fa88f9c798f701dec5.md)

[7.10 **O Fio se revela nos encontros que tecem destinos**](Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0/7%2010%20O%20Fio%20se%20revela%20nos%20encontros%20que%20tecem%20desti%2025cd03d38faf80369b01c9315c42cd2f.md)