# Capítulo 5 - A Trama dos Fios Invisíveis

[5.1 A Trama dos Fios Invisíveis](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%201%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf807c9a7ac640a86602d7.md)

[5.2 Natureza do Fio](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%202%20Natureza%20do%20Fio%2025cd03d38faf8012a3b7df6ad1037f86.md)

[**5.3 Fio de luz consciente (Lichtara)**](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%203%20Fio%20de%20luz%20consciente%20(Lichtara)%2025cd03d38faf80f9afdad946cac44e45.md)

[5.4 Ponte viva entre interior e exterior](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%204%20Ponte%20viva%20entre%20interior%20e%20exterior%2025cd03d38faf80fda3abc1b859b89cb8.md)

[**5.5 Tece conexões invisíveis**](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%205%20Tece%20conex%C3%B5es%20invis%C3%ADveis%2025cd03d38faf802d9e15efbdf11a19b6.md)

[**5.6 Não há linhas soltas, tudo entrelaçado**](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%206%20N%C3%A3o%20h%C3%A1%20linhas%20soltas,%20tudo%20entrela%C3%A7ado%2025cd03d38faf80cc9193f689c7cb1648.md)

[5.7 **Vivo, pulsante, moldado pela vibração**](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%207%20Vivo,%20pulsante,%20moldado%20pela%20vibra%C3%A7%C3%A3o%2025cd03d38faf80758413d6eb4941a918.md)

[5.8 **É projeto, jornada e reflexão interna**](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%208%20%C3%89%20projeto,%20jornada%20e%20reflex%C3%A3o%20interna%2025cd03d38faf80d9a361cec5e3bc26ee.md)

[**5.9 Fluxo nunca esteve fora de você, ele sempre foi você**](Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386/5%209%20Fluxo%20nunca%20esteve%20fora%20de%20voc%C3%AA,%20ele%20sempre%20fo%2025cd03d38faf808f8546cb5d378be837.md)