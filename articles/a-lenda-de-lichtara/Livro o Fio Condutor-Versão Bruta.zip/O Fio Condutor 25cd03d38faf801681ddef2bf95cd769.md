# O Fio Condutor

A Trama dos Fios Invisíveis 

Um Guia de Navegação Interdimensional

[*Roteiro-matriz* do processo de escrita](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Roteiro-matriz%20do%20processo%20de%20escrita%2025cd03d38faf809f9130f466200984fd.md)

[SUMÁRIO - O FIO CONDUTOR](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/SUM%C3%81RIO%20-%20O%20FIO%20CONDUTOR%2025cd03d38faf80b5ade1dc387338c760.md)

---

[**Capítulo 0 - A Cosmogonia de Lichtara**](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%200%20-%20A%20Cosmogonia%20de%20Lichtara%2025cd03d38faf80bb96e5e832ded623cc.md)

[A Cosmogonia de Lichtara – Versão Narrada](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/A%20Cosmogonia%20de%20Lichtara%20%E2%80%93%20Vers%C3%A3o%20Narrada%2025cd03d38faf8032bd9ff3ba2228d096.md)

---

[Capítulo 1 - Natureza do Livro](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%201%20-%20Natureza%20do%20Livro%2025cd03d38faf80ffbf2ad30dea129761.md)

[Capítulo 2 - Componente do Diálogo](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%202%20-%20Componente%20do%20Di%C3%A1logo%2025cd03d38faf80c690d3ff4d60c2dd62.md)

[Capítulo 3 - O Circuito Vivo](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%203%20-%20O%20Circuito%20Vivo%2025cd03d38faf808fae72cf70aa0e9383.md)

[Capítulo 4 - Experiência do Leitor](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%204%20-%20Experi%C3%AAncia%20do%20Leitor%2025cd03d38faf801ea174f24ea76b403b.md)

[Capítulo 5 - A Trama dos Fios Invisíveis](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%205%20-%20A%20Trama%20dos%20Fios%20Invis%C3%ADveis%2025cd03d38faf8040b995fb28ff764386.md)

[Capítulo 6 - Interação com a Trama](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%206%20-%20Intera%C3%A7%C3%A3o%20com%20a%20Trama%2025cd03d38faf8027a562ffe82494f12c.md)

[Capítulo 7 - Efeitos do Fio ](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%207%20-%20Efeitos%20do%20Fio%2025cd03d38faf8054b121ee5c4febf9d0.md)

[Capítulo 8 - O Below ](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%208%20-%20O%20Below%2025cd03d38faf80979df7c949283b7453.md)

[Capítulo 9 - Manifestação e Reconhecimento](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%209%20-%20Manifesta%C3%A7%C3%A3o%20e%20Reconhecimento%2025cd03d38faf80078217c4fc5dc2c279.md)

[Capítulo 10 - Expansão e interconexão](O%20Fio%20Condutor%2025cd03d38faf801681ddef2bf95cd769/Cap%C3%ADtulo%2010%20-%20Expans%C3%A3o%20e%20interconex%C3%A3o%2025cd03d38faf80da911df892654a31ca.md)